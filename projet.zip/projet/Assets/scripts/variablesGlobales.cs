﻿using UnityEngine;
using System.Collections;

public static class variablesGlobales {

	public static string paysActuel;
	public static victoriousCountry votoriousCountryInst;



}
